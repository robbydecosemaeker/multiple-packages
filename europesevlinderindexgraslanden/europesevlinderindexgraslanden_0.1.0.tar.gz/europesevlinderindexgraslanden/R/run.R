markupFile = "inst/demo.Rmd"
rmarkdown::render(markupFile, output_file = "../output/index.html")